#include <stdio.h>
#include <stdlib.h>
#define P 1999

int main()
{
    int N, R, f[P]={1,};
    scanf("%d %d",&N,&R);
    for(int i=1;i<=P-1;i++)
        f[i]=f[i-1]*i%P;
    int res=1;
    while(N&&R){
        int n=N%P;
        int r=R%P;
        if(n<r){
            res=0;
            break;
        }
        res=(res*f[n])%P;
        for(int i=0;i<P-2;i++)
            res=((res*f[r])%P*f[n-r])%P;
        N/=P,R/=P;
    }
    printf("%d",res);
    return 0;
}
