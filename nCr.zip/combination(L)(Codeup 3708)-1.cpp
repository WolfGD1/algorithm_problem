#include <stdio.h>
#include <stdlib.h>
#define MOD 100000007

int f[10001], n, r;
int inv[10001];
int mpow(int n, int p)
{
    if (p == 1) return n;
    int ret = mpow(n, p / 2);
    ret = (long long)ret * ret % MOD;
    if (p % 2) ret = (long long)n * ret % MOD;
    return ret;
}
void make_com()
{
    inv[0] = inv[1] = f[0] = f[1] = 1;
    for (int i = 2; i <= n; i++){
        f[i] = (long long)f[i - 1] * i % MOD;
    }
    for (int i = 2; i <= n; i++){
        inv[i] = (long long)inv[i - 1] * mpow(i, MOD - 2) % MOD;
    }
}
int C(int n, int r)
{
    return (long long)f[n] * inv[r] % MOD * inv[n - r] % MOD;
}
int main(void)
{
    scanf("%d %d", &n, &r);
    make_com();
    printf("%d", C(n, r));
    return 0;
}
