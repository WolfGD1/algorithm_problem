#include <stdio.h>
#include <stdlib.h>

int DT[32][32];
int f(int n, int k)
{
    if(k==n) DT[n][k]=1;
    else if(k==1) DT[n][k]=n;
    else
    {
        if(!DT[n][k])
            DT[n][k]=f(n-1,k-1)+f(n-1,k);
    }
    return DT[n][k];
}
int main()
{
    int n, k;
    scanf("%d %d", &n, &k);
    printf("%d\n", f(n,k));
    return 0;
}
